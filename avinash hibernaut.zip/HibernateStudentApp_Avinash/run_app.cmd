@echo off
setlocal
set JAVA_HOME=C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot
set PATH=%JAVA_HOME%\bin;C:\Users\desab\Downloads\HibernateStudentApp_Avinash\tools\apache-maven-3.9.9\bin;%PATH%
cd /d C:\Users\desab\Downloads\HibernateStudentApp_Avinash\HibernateStudentApp
del runlog.txt 2>nul
del exitcode.txt 2>nul
mvn compile exec:java -Dexec.mainClass=com.example.app.Main > runlog.txt 2>&1
echo %ERRORLEVEL% > exitcode.txt
exit /b %ERRORLEVEL%
