Set-Location "C:\Users\desab\Downloads\HibernateStudentApp_Avinash\HibernateStudentApp"
$env:JAVA_HOME = "C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot"
$env:Path = "$env:JAVA_HOME\bin;C:\Users\desab\Downloads\HibernateStudentApp_Avinash\tools\apache-maven-3.9.9\bin;$env:Path"
mvn -q compile
mvn -q dependency:build-classpath -DincludeScope=runtime -Dmdep.outputFile=cp.txt
$cp = (Get-Content "cp.txt" -Raw).Trim()
java -cp "target\classes;$cp" com.example.app.Main
