@echo off
setlocal
set TOOLS_DIR=C:\Users\desab\Downloads\HibernateStudentApp_Avinash\tools
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
powershell -NoLogo -NoProfile -Command "(New-Object Net.WebClient).DownloadFile('https://archive.apache.org/dist/maven/maven-3/3.9.9/binaries/apache-maven-3.9.9-bin.zip', '%TOOLS_DIR%\\maven.zip')"
powershell -NoLogo -NoProfile -Command "Expand-Archive -Path '%TOOLS_DIR%\\maven.zip' -DestinationPath '%TOOLS_DIR%' -Force"
set PATH=C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot\bin;%TOOLS_DIR%\apache-maven-3.9.9\bin;%PATH%
java -version > "%TOOLS_DIR%\javaversion.txt" 2>&1
mvn -version > "%TOOLS_DIR%\mavenversion.txt" 2>&1
echo done
