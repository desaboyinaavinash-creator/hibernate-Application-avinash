@echo off
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "C:\Users\desab\Downloads\HibernateStudentApp_Avinash\run_java.ps1"
