package com.example.app;

import com.example.entity.Student;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

    public static void main(String[] args) {

        try {
            // 1. INSERT or UPDATE (to make repeated runs safe)
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Transaction tx = session.beginTransaction();

                Student existingStudent = session.get(Student.class, 101);

                if (existingStudent == null) {
                    Student student = new Student(
                            101,
                            "Avinash",
                            "desaboyina.avinash@gmail.com",
                            "Artificial Intelligence and Data Science"
                    );

                    session.persist(student);
                    tx.commit();

                    System.out.println("Student inserted successfully.");
                    System.out.println("Inserted: " + student);
                } else {
                    existingStudent.setName("Avinash");
                    existingStudent.setEmail("desaboyina.avinash@gmail.com");
                    existingStudent.setCourse("Artificial Intelligence and Data Science");
                    tx.commit();

                    System.out.println("Student already existed; updated successfully.");
                    System.out.println("Updated: " + existingStudent);
                }
            }

            // 2. UPDATE
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Transaction tx = session.beginTransaction();

                Student student = session.get(Student.class, 101);

                if (student != null) {
                    student.setCourse("Data Science");
                }

                tx.commit();

                System.out.println("Student updated successfully.");
            }

            // 3. VERIFY
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Student student = session.get(Student.class, 101);

                System.out.println("Verified database record:");
                System.out.println(student);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}
