HIBERNATE STUDENT MAVEN PROJECT
================================

Project: HibernateStudentApp

Database configuration:
Host: db01.dbhost.dev
Port: 5051
Database: db_4555jbkny
Username: user_4555jbkny

Student:
ID: 101
Name: Avinash
Email: desaboyina.avinash@gmail.com
Initial Course: Artificial Intelligence and Data Science
Updated Course: Data Science

ECLIPSE IMPORT
--------------
1. Extract this ZIP file.
2. Open Eclipse.
3. File -> Import -> Maven -> Existing Maven Projects.
4. Select the extracted HibernateStudentApp folder.
5. Finish.
6. Right-click the project -> Maven -> Update Project.
7. Make sure Eclipse uses JDK 17 or later.
8. Open:
   src/main/java/com/example/app/Main.java
9. Right-click Main.java -> Run As -> Java Application.

DATABASE VERIFICATION
---------------------
Run this SQL in your database SQL editor:

SELECT id, name, email, course
FROM student
WHERE id = 101;

Expected final record:
101 | Avinash | desaboyina.avinash@gmail.com | Data Science

IMPORTANT
---------
The database password is included in hibernate.cfg.xml because this project
was prepared using the credentials supplied for this lab project. Do not
share the ZIP publicly. If this database credential is temporary, change
or rotate it after completing the project.

If ID 101 already exists, the INSERT operation will fail with a duplicate
primary-key error. Delete that test row or change the ID in Main.java before
running the project again.
